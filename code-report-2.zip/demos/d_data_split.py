# -*- coding: utf-8 -*-
"""
Created on Thu Oct 11 19:13:52 2018

@author: lenovo
"""
from utils import to_pickle



feature_set=to_pickle.load_pickle(u'feature_set.pickle')

KPIs=to_pickle.load_pickle(u'feature_set.pickle')

for key in feature.keys():
    feature[key]=feature[key].dropna()



from pandas import DataFrame,Series
from sklearn.model_selection import StratifiedKFold




skf = StratifiedKFold(n_splits=3)
skf.get_n_splits(X, y)

print(skf)  

for train_index, test_index in skf.split(X, y):
   print("TRAIN:", train_index, "TEST:", test_index)
   X_train, X_test = X[train_index], X[test_index]
   y_train, y_test = y[train_index], y[test_index]