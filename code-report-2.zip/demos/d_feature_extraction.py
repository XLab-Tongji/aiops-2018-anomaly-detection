# -*- coding: utf-8 -*-
"""
Created on Tue Oct  9 16:01:07 2018

@author: lenovo
"""

# =============================================================================
# data_import
# =============================================================================
    
import pandas as pd
import time
import pickle
import os
TIMESTAMP="%Y%m%d%H%M%S"
anomaly=pd.read_csv(r"E:\phase2_train.csv")
anomaly['timestamp'] =anomaly['timestamp'].astype(float)
anomaly['timestamp'] =pd.to_datetime(anomaly['timestamp'].apply(lambda x: time.strftime(TIMESTAMP,time.localtime(x))))


# 保存数据方便调用

pickle_file = 'timeStamp_pre_process.pickle'
if not os.path.isfile(pickle_file):    #判断是否存在此文件，若无则存储
    print('Saving data to pickle file...')
    try:
        with open(pickle_file, 'wb') as pfile:
            pickle.dump(
                {
                    'anomaly': anomaly
                },
                pfile, pickle.HIGHEST_PROTOCOL)
    except Exception as e:
        print('Unable to save data to', pickle_file, ':', e)
        raise

print('Data cached in pickle file.')


# =============================================================================
# NAN_value_dropout
# =============================================================================   
anomaly=anomaly.dropna()

# =============================================================================
# KPIs 
# =============================================================================
anomaly2=anomaly.groupby(by=['KPI ID'])
KPIt=anomaly2.groups #dictinary

KPIs={}
for key in KPIt:
    start=list(KPIt[key])[0]
    end=list(KPIt[key])[-1]
    KPIs[key]=anomaly[start:end]
    
pickle_file = 'KPIs.pickle'
if not os.path.isfile(pickle_file):    #判断是否存在此文件，若无则存储
    print('Saving data to pickle file...')
    try:
        with open(pickle_file, 'wb') as pfile:
            pickle.dump(
                {
                    'KPIs': KPIs
                },
                pfile, pickle.HIGHEST_PROTOCOL)
    except Exception as e:
        print('Unable to save data to', pickle_file, ':', e)
        raise

print('Data cached in pickle file.') 

# =============================================================================
# feature 
# key='05f10d3a-239c-3bef-9bdc-a2feeb0037aa'
# KPIs[key].index=KPIs[key]['timestamp']
# df = pd.Series(KPIs[key]['value'])
# b=df.rolling(window=int(len(KPIs[key])/100)).mean()
# =============================================================================


if 'KPIs' not in locals() and 'KPIs' not in globals():
    import pickle
    
    pickle_file = u'E:\\a_school\智能运维\code\KPIs.pickle'
    
    with open(pickle_file, 'rb') as f:
      pickle_data = pickle.load(f)       # 反序列化，与pickle.dump相反
      KPIs=pickle_data['KPIs']
      del pickle_data  # 释放内存

window_mean={}
window_var={}
window_diff={}
window_var_diff={}
window_mean_diff={}
window_var_diff_ratio={}
window_mean_diff_ratio={}
w=[1,5,9,20,30,50,70,100]
for i in range(len(w)):
    window_mean[w[i]]=[]
    window_var[w[i]]=[]
    window_var_diff[w[i]]=[]
    window_mean_diff[w[i]]=[]
    window_var_diff_ratio[w[i]]=[]
    window_mean_diff_ratio[w[i]]=[]
    for key in KPIs:
         print(w[i],key)
         KPIs[key].index=KPIs[key]['timestamp']
         df = pd.Series(KPIs[key]['value'])
         
         w_mean=df.rolling(window=w[i]).mean()
         w_var=df.rolling(window=w[i]).var()
         w_mean_diff=df.rolling(window=w[i]).mean().diff()
         w_var_diff=df.rolling(window=w[i]).var().diff()
         
         window_mean[w[i]].append(w_mean)
         window_var[w[i]].append(w_var)
         window_mean_diff[w[i]].append(w_mean_diff)
         window_var_diff[w[i]].append(w_var_diff)
         window_mean_diff_ratio[w[i]].append(w_mean_diff/w_mean)
         window_var_diff_ratio[w[i]].append(w_var_diff/w_var)
         
import os
import pickle
pickle_file = 'Feature1.pickle'
if not os.path.isfile(pickle_file):    #判断是否存在此文件，若无则存储
    print('Saving data to pickle file...')
    try:
        with open(pickle_file, 'wb') as pfile:
            pickle.dump(
                {
                   'window_mean':window_mean,
                   'window_var':window_var,
                   'window_var_diff':window_var_diff,
                   'window_mean_diff':window_mean_diff,
                   'window_var_diff_ratio':window_var_diff_ratio,
                   'window_mean_diff_ratio':window_mean_diff_ratio
                },
                pfile, pickle.HIGHEST_PROTOCOL)
    except Exception as e:
        print('Unable to save data to', pickle_file, ':', e)
        raise

print('Data cached in pickle file.') 
        
         
 