# -*- coding: utf-8 -*-
"""
Created on Thu Oct 11 09:40:55 2018

@author: lenovo
"""
import pickle

pickle_file = u'E:\\a_school\智能运维\code\Feature1.pickle'

with open(pickle_file, 'rb') as f:
    pickle_data = pickle.load(f)
    window_mean=pickle_data['window_mean']
    window_var=pickle_data['window_var']
    window_var_diff=pickle_data['window_var_diff']
    window_mean_diff=pickle_data['window_mean_diff']
    window_var_diff_ratio=pickle_data['window_var_diff_ratio']
    window_mean_diff_ratio=pickle_data['window_mean_diff_ratio']
    del pickle_data  # release memory
  
pickle_file = u'E:\\a_school\智能运维\code\KPIs.pickle'

with open(pickle_file, 'rb') as f:
    pickle_data = pickle.load(f)
    KPIs=pickle_data['KPIs']
    del pickle_data  # release memory# 

import pandas as pd

feature={}
window_sizes=list(window_mean.keys())
s=window_sizes[3]
i=2
kpi_ids=list(KPIs.keys())
key=kpi_ids[2]

window_size=[int(s)]*len(window_mean[s][i])

window_size_serie=pd.Series(window_size,index=window_mean[s][i].index)

series=[window_size_serie,
        window_mean[s][i],
        window_var[s][i],
        window_var_diff[s][i],
        window_mean_diff[s][i],
        window_mean_diff_ratio[s][i],
        window_var_diff_ratio[s][i]
        ]
feature_set_s=pd.concat(series,axis=1,keys=['window_size','mean','var','var_diff','mean_diff','mean_diff_ratio','var_diff_ratio'])

if key in feature:
    feature[key]=pd.concat([feature[key],feature_set_s])
else:
    feature[key]=feature_set_s
    