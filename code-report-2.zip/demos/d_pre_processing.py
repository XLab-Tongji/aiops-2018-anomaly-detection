# -*- coding: utf-8 -*-
"""
Created on Sat Sep 29 07:53:38 2018

@author: lenovo
"""

    

# =============================================================================
# data_import
# =============================================================================
    
import pandas as pd
import time
import pickle
import os
TIMESTAMP="%Y%m%d%H%M%S"
anomaly=pd.read_csv(r"E:\phase2_train.csv")
anomaly['timestamp'] =anomaly['timestamp'].astype(float)
anomaly['timestamp'] =pd.to_datetime(anomaly['timestamp'].apply(lambda x: time.strftime(TIMESTAMP,time.localtime(x))))


# =============================================================================
# save_middle_results
# =============================================================================

pickle_file = 'timeStamp_pre_process.pickle'
if not os.path.isfile(pickle_file):    #判断是否存在此文件，若无则存储
    print('Saving data to pickle file...')
    try:
        with open(pickle_file, 'wb') as pfile:
            pickle.dump(
                {
                    'anomaly': anomaly
                },
                pfile, pickle.HIGHEST_PROTOCOL)
    except Exception as e:
        print('Unable to save data to', pickle_file, ':', e)
        raise

print('Data cached in pickle file.')


# =============================================================================
# NAN_value_dropout
# =============================================================================   
anomaly=anomaly.dropna()

# =============================================================================
# KPIs 
# =============================================================================
anomaly2=anomaly.groupby(by=['KPI ID'])
KPIt=anomaly2.groups #dictinary

for key in KPIt:
    print (key,'corresponds to',len(KPIt[key]))

# =============================================================================
# KPIs_date
# =============================================================================

# =============================================================================
# data_visualization
# =============================================================================    

import matplotlib.pyplot as plt
KPI1=anomaly[list(KPIt['05f10d3a-239c-3bef-9bdc-a2feeb0037aa'])[0]:list(KPIt['05f10d3a-239c-3bef-9bdc-a2feeb0037aa'])[-1]]
plt.figure(figsize=(50,5))
a=KPI1[:]
a_exp=a[a['label']==1]
a_nrm=a[a['label']==0]
plt.plot(a_nrm['timestamp'],a_nrm['value'], 'b--', linewidth=0.2, markersize=1)
plt.scatter(a_exp['timestamp'],a_exp['value'],marker='o',c='red',s=100)
plt.savefig('./KPI1.jpg')
plt.show()

# =============================================================================
# preprocess
# 
# data_resampled ----》X_resampled,y_resampled (3655640,2);(3655640,)
# weight_adjust ----?
# =============================================================================


from imblearn.over_sampling import SMOTE
from collections import Counter
X=anomaly[['timestamp','value']]
y=anomaly['label']
ratio={1:int(len(y[y==0])*0.25)}
X_resampled, y_resampled = SMOTE(ratio=ratio,kind='borderline1').fit_sample(X, y)
print(Counter(y_resampled).items()) #dict_items([(0, 2924512), (1, 731128)])

X_df=pd.DataFrame(X_resampled)
y_df=pd.DataFrame(y_resampled)
anomaly_resampled=pd.concat([X_df,y_df],axis=1) 
anomaly_resampled.columns=['timestamp','value','label']


from sklearn import preprocessing

value_scaled = preprocessing.scale(anomaly_resampled['value'])
anomaly_resampled['value']=pd.Series(value_scaled)
# =============================================================================
# feature_extraction
# =============================================================================

value_groupby_mean=anomaly_resampled[['value','label']].groupby(by='label').mean()




    