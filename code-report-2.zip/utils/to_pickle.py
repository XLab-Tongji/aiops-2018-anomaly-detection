# -*- coding: utf-8 -*-
"""
Created on Wed Oct 10 21:09:32 2018

@author: lenovo
"""

import os
import pickle
def save_as_pickle(filename,data):
    """
    :param filename is a string object like "*.pickle"
    :param data is a dict object
    
    """
    pickle_file = filename
     #判断是否存在此文件，若无则存储
    print('Saving data to pickle file...')
    try:
        with open(filename, 'wb') as pfile:
            pickle.dump(
                data,
                pfile, pickle.HIGHEST_PROTOCOL)
    except Exception as e:
        print('Unable to save data to', pickle_file, ':', e)
        raise
    
    print('Data cached in pickle file.')
 
def load_pickle(filename):
     """
    :param filename is a string object like "*.pickle"
    :param data is a dict object
    
    """
    with open(filename, 'rb') as f:
        pickle_data = pickle.load(f)
        data={}
        for key in data.keys():
            data[key]=f[key]
        del pickle_data  # release memory
    return data