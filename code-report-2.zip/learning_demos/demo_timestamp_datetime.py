# -*- coding: utf-8 -*-
"""
Created on Sun Sep 30 09:00:00 2018

@author: lenovo
"""
import time
ISFORMAT="%Y-%m-%d %H:%M:%S"
TIMESTAMP="%Y%m%d%H%M%S"


x = time.localtime(1476460800.0)# localtime参数为float类型，这里1476460800.0为float类型

print(time.strftime(TIMESTAMP,x))#    1，时间戳转化为struct_time
print(time.strftime(ISFORMAT,x)) #    2，struct_time转化为指定格式日期字符串

# =============================================================================
# result
# ref:https://blog.csdn.net/longshenlmj/article/details/13627537
# =============================================================================
# 20161015000000
# 2016-10-15 00:00:00