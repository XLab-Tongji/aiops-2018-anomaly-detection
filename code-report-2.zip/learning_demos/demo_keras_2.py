# -*- coding: utf-8 -*-
"""
Created on Wed Oct 10 18:31:47 2018

@author: lenovo
"""
from keras.models import Sequential
from keras.layers import Dense, Activation

model = Sequential([
    Dense(32,activation='relu',input_dim=784),
    Dense(10,activation='softmax',input_dim=784),
])