# -*- coding: utf-8 -*-
"""
Created on Tue Oct  9 14:23:27 2018

@author: lenovo
"""

#!/usr/bin/python
#-*- coding:cp936 -*-
inpath = u'E:\\a_school\智能运维\code\test.txt'

fin = open(inpath)