# -*- coding: utf-8 -*-
"""
Created on Tue Oct  9 15:37:47 2018

@author: lenovo
"""

import matplotlib.pylab
import numpy as np
import pandas as pd

df = pd.Series(np.random.randn(600), index = pd.date_range('7/1/2016', freq = 'D', periods = 600))
r = df.rolling(window = 10)

#r.max, r.median, r.std, r.skew, r.sum, r.var

df.plot(style='r--')
df.rolling(window=10).mean().plot(style='b')