# -*- coding: utf-8 -*-
"""
Created on Sun Sep 30 09:26:01 2018

@author: lenovo
"""
import os
import pickle
train_features=[[1,0.1,2],[2,0.3,3]]
train_labels=[[1],[0]]

valid_features=[[2,0.9,0.1],[2,1,0.1]]
valid_labels=[[0],[0]]

test_features=[[0.3,0.2,1],[0.3,2,0.5]]
test_labels=[[1],[1]]

# 保存数据方便调用
pickle_file = 'notMNIST.pickle'
if not os.path.isfile(pickle_file):    #判断是否存在此文件，若无则存储
    print('Saving data to pickle file...')
    try:
        with open('notMNIST.pickle', 'wb') as pfile:
            pickle.dump(
                {
                    'train_dataset': train_features,
                    'train_labels': train_labels,
                    'valid_dataset': valid_features,
                    'valid_labels': valid_labels,
                    'test_dataset': test_features,
                    'test_labels': test_labels,
                },
                pfile, pickle.HIGHEST_PROTOCOL)
    except Exception as e:
        print('Unable to save data to', pickle_file, ':', e)
        raise

print('Data cached in pickle file.')

#%matplotlib inline     #直接将绘图显示在当前页面，用于jupyter notebook

# 加载模块


import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt

# 读取数据
pickle_file = 'notMNIST.pickle'
with open(pickle_file, 'rb') as f:
  pickle_data = pickle.load(f)       # 反序列化，与pickle.dump相反
  train_features = pickle_data['train_dataset']
  train_labels = pickle_data['train_labels']
  valid_features = pickle_data['valid_dataset']
  valid_labels = pickle_data['valid_labels']
  test_features = pickle_data['test_dataset']
  test_labels = pickle_data['test_labels']
  del pickle_data  # 释放内存

print('Data and modules loaded.')



