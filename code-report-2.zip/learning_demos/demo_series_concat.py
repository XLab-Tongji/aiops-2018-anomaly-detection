# -*- coding: utf-8 -*-
"""
Created on Thu Oct 11 08:09:29 2018

@author: lenovo
"""

import pandas as pd

sr1=pd.Series([1,2])
sr2=pd.Series([3,4])
df1=pd.concat([sr1,sr2],keys=['one','two'])
print(df1)
sr3=pd.Series([5])
df1['three']=sr3
print(df1)
df2=pd.DataFrame([[1,2,3],[3,4,5],[5,6,7]],columns=['one','two','three'])

pd.concat([df1,df2],ignore_index=True)