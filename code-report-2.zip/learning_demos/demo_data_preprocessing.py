# -*- coding: utf-8 -*-
"""
Created on Sun Sep 30 09:36:11 2018

@author: lenovo
"""

import hashlib
import os
import pickle
from urllib.request import urlretrieve

import numpy as np
from PIL import Image 
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelBinarizer
from sklearn.utils import resample
from tqdm import tqdm
from zipfile import ZipFile

print('All modules imported.')


def download(url, file):
    """
    从<url>处下载数据
    :参数 url: 文件的URL
    :参数 file: 本地文件的路径
    """
    if not os.path.isfile(file):
        print('Downloading ' + file + '...')
        urlretrieve(url, file)
        print('Download Finished')

# 分别下载训练集和测试集.
download('https://s3.amazonaws.com/udacity-sdc/notMNIST_train.zip', 'notMNIST_train.zip')
download('https://s3.amazonaws.com/udacity-sdc/notMNIST_test.zip', 'notMNIST_test.zip')

# 校验MD5值，确保下载的数据是完整的
assert hashlib.md5(open('notMNIST_train.zip', 'rb').read()).hexdigest() == 'c8673b3f28f489e9cdf3a3d74e2ac8fa',\
        'notMNIST_train.zip file is corrupted.  Remove the file and try again.'
assert hashlib.md5(open('notMNIST_test.zip', 'rb').read()).hexdigest() == '5d3c7e653e63471c88df796156a9dfa9',\
        'notMNIST_test.zip file is corrupted.  Remove the file and try again.'

# 直到所有文件下载完，给出下列提示.
print('All files downloaded.')

def uncompress_features_labels(file):
    """
    从zip文件中解压出features和labels
    :参数 file: 待解压文件
    """
    features = []
    labels = []

    with ZipFile(file) as zipf:
        # 进度条
        filenames_pbar = tqdm(zipf.namelist(), unit='files')

        # 从所有文件中提取features和labels
        for filename in filenames_pbar:
            # 检查文件名是否为目录，不是则往下执行
            if not filename.endswith('/'):       #str.endswith()
                #ZipFile.open()以二进制的形式访问文件
                with zipf.open(filename) as image_file:
                    image = Image.open(image_file)
                    image.load()
                    # 将图像数据以一维矩阵形式存储
                    # 存储格式设定为 float32
                    feature = np.array(image, dtype=np.float32).flatten()

                # 提取文件名的首位，存储为对应的label。
                # os.path.split()分割为“路径+文件名”，文件名中无'/'
                label = os.path.split(filename)[1][0]

                features.append(feature)
                labels.append(label)
    return np.array(features), np.array(labels)

# 从zip文件中提取出train和test数据集中的features和labels
train_features, train_labels = uncompress_features_labels('notMNIST_train.zip')
test_features, test_labels = uncompress_features_labels('notMNIST_test.zip')

# 重新采样，数据大小限制为docker_size_limit
docker_size_limit = 150000
train_features, train_labels = resample(train_features, train_labels, n_samples=docker_size_limit)

# 为特征工程设置标记，防止跳过重要步骤
is_features_normal = False
is_labels_encod = False

# 直到所有features和labels被解压，打印以下内容
print('All features and labels uncompressed.')


