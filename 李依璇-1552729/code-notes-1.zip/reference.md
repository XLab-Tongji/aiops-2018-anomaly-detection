3.处理不平衡样本
权重法：每个class加一个class weight{与该类别样本数量成反比}，
https://www.cnblogs.com/pinard/p/9093890.html

过采样SMOTE--算法
smote算法优点：减弱过拟合
smote+borderline1
https://www.cnblogs.com/itdyb/p/9068904.html



特征选择与特征提取
sklearn.model_selection pca特征降维
sklearn.model_extraction 特征向量构造
https://blog.csdn.net/henryczj/article/details/41284201





![](E:\a_school\智能运维\note_pics\Page0001.jpg)



![](E:\a_school\智能运维\note_pics\Page0013.jpg)

![Page0014](E:\a_school\智能运维\note_pics\Page0014.jpg)